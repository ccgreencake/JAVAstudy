package Sept_seventh;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @Author : LiuDongBin
 * @create 2023/9/6 15:14
 */
public class exam1 {
    public static void main(String[] args) {
//        案例：如果成绩大于90，奖励豪华作业题一套
        System.out.println("请输入成绩：");
        Scanner scanner = new Scanner(System.in);
        int score = scanner.nextInt();
        if (score > 90) {
            System.out.println("奖励豪华作业题一套");
        }
//        案例：如果年龄大于65，可以领取养老金
        System.out.println("请输入年龄：");
        int age = scanner.nextInt();
        if (age > 65) {
            System.out.println("可以领取养老金");
        }
//        案例：如果身高大于180，且体重小于180,就可以当模特
        System.out.println("请输入身高：");
        int height = scanner.nextInt();
        System.out.println("请输入体重：");
        int weight = scanner.nextInt();
        if (height > 180 && weight < 180) {
            System.out.println("可以当模特");
        }
    }

}
