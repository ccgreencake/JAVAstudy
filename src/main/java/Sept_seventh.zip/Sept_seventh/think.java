package Sept_seventh;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @Author : LiuDongBin
 * @create 2023/9/6 15:34
 */
public class think {
    public static void main(String[] args) {
//        a、思考题:输入年月日，求这一天是这一年的第几天
        System.out.println("请输入年");
        Scanner scanner = new Scanner(System.in);
        int year = scanner.nextInt();
        System.out.println("请输入月");
        //可以加上月份和日的判断，比如月应该小于等于12，日根据月来小于31等，判断输入是否有错误，这里就不写了。
        int month = scanner.nextInt();
        System.out.println("请输入日");
        int day = scanner.nextInt();
        int finalDay = whichDay(year,month,day);
        System.out.println("是第" + finalDay + "天");


//	b、思考题:输入年月日，输出这一天是星期几(提示：1900年1月1日星期1)
        //因为需要用到上面的第几天所以将上面的方法打包
//        先判断离1900年多少天
        int newFinalDay = 0;
        for (int i = 1900; i < year; i++) {
            if(i%4 == 0 && i/100 != 0 )
                newFinalDay += 366;
            else
                newFinalDay += 365;
        }
        newFinalDay+=finalDay;
        switch (newFinalDay%7){
            case 0:
                System.out.println("周日");
                break;
            case 1:
                System.out.println("周一");
                break;
            case 2:
                System.out.println("周二");
                break;
            case 3:
                System.out.println("周三");
                break;
            case 4:
                System.out.println("周四");
                break;
            case 5:
                System.out.println("周五");
                break;
            case 6:
                System.out.println("周六");
                break;
        }

    }

    static int whichDay(int year, int month, int day){

        int finalDay = 0;
        for (int i = 1; i < month; i++) {
            switch(i){
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    finalDay = finalDay + 31;
                    break;
                case 2:
//                    判断闰年
                    if (year%4 == 0 && year/100 != 0 )
                        finalDay = finalDay + 29;
                    else
                        finalDay = finalDay + 28;
                    break;
                default:
                    finalDay = finalDay + 30;
                    break;
            }
        }
        finalDay = finalDay + day;
        return finalDay;
    }

}

