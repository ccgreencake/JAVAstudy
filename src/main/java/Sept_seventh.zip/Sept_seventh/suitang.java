package Sept_seventh;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @Author : LiuDongBin
 * @create 2023/9/6 15:23
 */
public class suitang {
    public static void main(String[] args) {
//        简单if、if...else练习
//1、输入年龄，如果年龄大于18周岁，输出可以进入网吧上网
        System.out.println("请输入年龄：");
        Scanner scanner = new Scanner(System.in);
        int age = scanner.nextInt();
        if (age > 18) {
            System.out.println("可以进入网吧上网");
        }
//2、输入一个年份，判断这个年份是否是闰年，如果是输出闰年，如果不是输出平年
        System.out.println("请输入年份：");
        int year = scanner.nextInt();
        if (year % 4 == 0 && year % 100 != 0) {
            System.out.println("闰年");
        } else {
            System.out.println("平年");
        }
//3、如果java成绩大于90且sql成绩大于85，或者音乐成绩等于100且语文大于95，
//输出奖励一个 华为手机。否则输出晚自习增加一个小时
        System.out.println("请输入java成绩：");
        int java = scanner.nextInt();
        System.out.println("请输入sql成绩：");
        int sql = scanner.nextInt();
        System.out.println("请输入音乐成绩：");
        int music = scanner.nextInt();
        System.out.println("请输入语文成绩：");
        int chinese = scanner.nextInt();
        if ((java > 90 && sql > 85) || (music == 100 && chinese > 95)) {
            System.out.println("奖励一个 华为手机");
        } else {
            System.out.println("晚自习增加一个小时");
        }

//多重if、嵌套if练习
//1、如果成绩大于90 优秀
//80 良好
//70 中等
//60 及格
//小于60 不及格
        System.out.println("请输入成绩：");
        int score = scanner.nextInt();
        if (score > 90) {
            System.out.println("优秀");
        } else if (score > 80) {
            System.out.println("良好");
        } else if (score > 70) {
            System.out.println("中等");
        } else if (score > 60) {
            System.out.println("及格");
        } else {
            System.out.println("不及格");
        }
//2、商场做活动，满300可以打折，会员打8折，非会员打9折，输出消费金额
        System.out.println("请输入消费金额：");
        int money = scanner.nextInt();
        System.out.println("是否是会员：");
        String isVip = scanner.next();
        if (money >= 300) {
            if (isVip.equals("是")) {
                System.out.println("消费金额为：" + money * 0.8);
            } else {
                System.out.println("消费金额为：" + money * 0.9);
            }
        } else {
            System.out.println("消费金额为：" + money);
        }
//switch练习
//1、定义一个季节，打印这个季节有哪几个月
        System.out.println("请输入季节：");
        String season = scanner.next();
        switch (season) {
            case "春":
                System.out.println("3月、4月、5月");
                break;
            case "夏":
                System.out.println("6月、7月、8月");
                break;
            case "秋":
                System.out.println("9月、10月、11月");
                break;
            case "冬":
                System.out.println("12月、1月、2月");
                break;
            default:
                System.out.println("输入有误");
                break;
        }
//2、输入月份，打印这个月份是什么季节
        System.out.println("请输入月份：");
        int month = scanner.nextInt();
        switch (month) {
            case 3:
            case 4:
            case 5:
                System.out.println("春");
                break;
            case 6:
            case 7:
            case 8:
                System.out.println("夏");
                break;
            case 9:
            case 10:
            case 11:
                System.out.println("秋");
                break;
            case 12:
            case 1:
            case 2:
                System.out.println("冬");
                break;
            default:
                System.out.println("输入有误");
                break;
        }
//3、把之前做的90优秀这个题用switch实现
        System.out.println("请输入成绩：");
        int score1 = scanner.nextInt();
        switch (score1 / 10) {
            case 10:
            case 9:
                System.out.println("优秀");
                break;
            case 8:
                System.out.println("良好");
                break;
            case 7:
                System.out.println("中等");
                break;
            case 6:
                System.out.println("及格");
                break;
            default:
                System.out.println("不及格");
                break;
        }
    }
}
