package Sept_seventh;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @Author : LiuDongBin
 * @create 2023/9/6 15:20
 */
public class exam5 {
    public static void main(String[] args) {
//        选择1:查询操作
//选择2:增加操作
//选择3:删除操作
//选择4:修改操作
//选择5:退出系统
//选择其他：提示输入有误
        System.out.println("请选择操作：");
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();
        switch (choice){
            case 1:
                System.out.println("查询操作");
                break;
            case 2:
                System.out.println("增加操作");
                break;
            case 3:
                System.out.println("删除操作");
                break;
            case 4:
                System.out.println("修改操作");
                break;
            case 5:
                System.out.println("退出系统");
                break;
            default:
                System.out.println("提示输入有误");
                break;
        }
    }
}
