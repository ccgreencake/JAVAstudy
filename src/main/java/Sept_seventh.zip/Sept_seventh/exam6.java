package Sept_seventh;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @Author : LiuDongBin
 * @create 2023/9/6 15:22
 */
public class exam6 {
    public static void main(String[] args) {
//        （要求选择A和a是一样的结果）
//选择A: 好评
//选择B: 一般
//选择C: 良好
//选择D: 差评
        System.out.println("请选择评价：");
        Scanner scanner = new Scanner(System.in);
String evaluate = scanner.next();
        switch(evaluate){
            case "A":
            case "a":
                System.out.println("好评");
                break;
            case "B":
            case "b":
                System.out.println("一般");
                break;
            case "C":
            case "c":
                System.out.println("良好");
                break;
            case "D":
            case "d":
                System.out.println("差评");
                break;
            default:
                System.out.println("输入有误");
                break;
        }

    }
}
