package Sept_seventh;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @Author : LiuDongBin
 * @create 2023/9/6 15:17
 */
public class exam4 {
    public static void main(String[] args) {
//        学校举行跑步比赛，如果成绩在15秒以内，可以进入决赛，男的进入男子组决赛，女的进入女子
//组决赛
        System.out.println("请输入成绩：");
        Scanner scanner = new Scanner(System.in);
        double score = scanner.nextDouble();
        System.out.println("请输入性别");
        String sex = scanner.next();
        if (score<15){
            if (sex.equals("男")) {
                System.out.println("进入男子组决赛");
            }else{
                System.out.println("进入女子组决赛");
            }
        }else{
            System.out.println("不能进入决赛");
        }
    }
}
