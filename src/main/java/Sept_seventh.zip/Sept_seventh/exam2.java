package Sept_seventh;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @Author : LiuDongBin
 * @create 2023/9/6 15:15
 */
public class exam2 {
    public static void main(String[] args) {
//        案例：如果用户名为admin、密码为123456，则跳转首页，否则跳转登录页面
//案例：如果身上余额大于100元。中午吃饭加个鸡腿，否则泡面
        System.out.println("请输入用户名：");
        Scanner scanner = new Scanner(System.in);
        String username = scanner.next();
        System.out.println("请输入密码：");
        String password = scanner.next();
        if (username.equals("admin") && password.equals("123456")) {
            System.out.println("跳转首页");
        } else {
            System.out.println("跳转登录页面");
        }
        System.out.println("请输入身上余额：");
        int money = scanner.nextInt();
        if (money > 100) {
            System.out.println("中午吃饭加个鸡腿");
        } else {
            System.out.println("泡面");
        }

    }
}
