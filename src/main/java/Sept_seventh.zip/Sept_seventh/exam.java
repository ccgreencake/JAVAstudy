package Sept_seventh;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @Author : LiuDongBin
 * @create 2023/9/6 15:28
 */
public class exam {
    public static void main(String[] args) {
//        1、如果年龄够7岁，或者年龄够5岁并且性别是“男”，就可以搬动桌子
        System.out.println("请输入年龄：");
        Scanner scanner = new Scanner(System.in);
        int age = scanner.nextInt();
        System.out.println("请输入性别");
        String sex = scanner.next();
        if(age >= 7 || age >= 5 && sex.equals("男")){
            System.out.println("可以搬动桌子");
        }else{
            System.out.println("不可以搬动桌子");
        }
//2、从键盘输入一个整数，判断是否能被3或者被5整除。能的话输出："该数是3或5的倍数",否则输出："该数不能被3或5中的任何一个数整除"
        System.out.println("请输入一个整数：");
        int num = scanner.nextInt();
        if(num % 3 == 0 || num % 5 == 0){
            System.out.println("该数是3或5的倍数");
        }else{
            System.out.println("该数不能被3或5中的任何一个数整除");
        }
//3、用户输入两个数a和b，如果a能被b整除或者a加b大于100，则输出a，否则输出b。
        System.out.println("请输入a：");
        int a = scanner.nextInt();
        System.out.println("请输入b：");
        int b = scanner.nextInt();
        if(a % b == 0 || a + b > 100){
            System.out.println(a);
        }else{
            System.out.println(b);
        }
//4、按照年龄划分，60以上是老年人,40-60是中年人,20-40青年人,10-20青少年,10岁以下儿童。(分别使用多重if和switch语句实现)
        System.out.println("请输入年龄：");
        int age1 = scanner.nextInt();
        if(age1 >= 60){
            System.out.println("老年人");
        }else if(age1 >= 40 && age1 < 60){
            System.out.println("中年人");
        }
        else if(age1 >= 20 && age1 < 40){
            System.out.println("青年人");
        }
        else if(age1 >= 10 && age1 < 20){
            System.out.println("青少年");
        }
        else if(age1 < 10){
            System.out.println("儿童");
        }
        switch(age1/10){
            case 0:
                System.out.println("儿童");
                break;
            case 1:
                System.out.println("青少年");
                break;
            case 2:
                System.out.println("青年人");
                break;
            case 3:
            case 4:
                System.out.println("中年人");
                break;
            default:
                System.out.println("老年人");
                break;
        }
//5、需求说明：
//会员购物时，根据输入积分的不同享受不同的折扣
//计算会员购物时获得的折扣输出实付金额
//会员积分x	 		折扣
//x ＜ 2000			9折
//2000 ≤ x ＜ 4000	8折
//4000 ≤ x ＜ 8000	7折
//x ≥ 8000			6折

        System.out.println("请输入积分：");
        int score = scanner.nextInt();
        if(score < 2000){
            System.out.println("折扣为9折");
        }else if(score >= 2000 && score < 4000){
            System.out.println("折扣为8折");
        }else if(score >= 4000 && score < 8000){
            System.out.println("折扣为7折");
        }else if(score >= 8000){
            System.out.println("折扣为6折");
        }
//
//6、张三为他的手机设定了自动拨号
//按1：拨爸爸的号
//按2：拨妈妈的号
//按3：拨爷爷的号
//按4：拨奶奶的号
        System.out.println("请输入数字：");
        int n = scanner.nextInt();
        switch (n){
            case 1:
                System.out.println("拨爸爸的号");
                break;
            case 2:
                System.out.println("拨妈妈的号");
                break;
            case 3:
                System.out.println("拨爷爷的号");
                break;
            case 4:
                System.out.println("拨奶奶的号");
                break;
            default:
                System.out.println("输入错误");
                break;
        }
    }
}
