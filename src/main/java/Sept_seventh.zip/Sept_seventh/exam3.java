package Sept_seventh;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @Author : LiuDongBin
 * @create 2023/9/6 15:16
 */
public class exam3 {
    public static void main(String[] args) {
//        案例：
//根据手上的余额选择购买的手机品牌
//如果大于10000, 买个苹果
//如果大于7000, 买个华为
//如果大于5000,买个小米
//如果大于3000,买个诺基亚
//否则,去打公共电话
        System.out.println("请输入手上的余额：");
        Scanner scanner = new Scanner(System.in);
        int money = scanner.nextInt();
        if (money > 10000) {
            System.out.println("买个苹果");
        } else if (money > 7000) {
            System.out.println("买个华为");
        } else if (money > 5000) {
            System.out.println("买个小米");
        } else if (money > 3000) {
            System.out.println("买个诺基亚");
        } else {
            System.out.println("去打公共电话");
        }
    }
}
